/**
 * SO, 2016
 * Lab #1, Introduction
 *
 * Task #3, Linux
 *
 * Multiple source files compiling
 * mul.h - multiplication header file
 */

#ifndef _MUL_H
#define _MUL_H

int mul(int a, int b);

#endif
