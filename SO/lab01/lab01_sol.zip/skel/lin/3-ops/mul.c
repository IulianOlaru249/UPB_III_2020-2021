/**
 * SO, 2016
 * Lab #1, Introduction
 *
 * Task #3, Linux
 *
 * Multiple source files compiling
 */

/**
 * mul - multiplication of two integers
 * @a: first integer
 * @b: second integer
 *
 * RETURNS: product @a * @b
 */
int mul(int a, int b)
{
	return a * b;
}
