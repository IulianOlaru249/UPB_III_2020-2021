/**
 * SO, 2016
 * Lab #1, Introduction
 *
 * Task #3, Linux
 *
 * Multiple source files compiling
 */

/**
 * add - adds to integers
 * @a: first integer
 * @b: second integer
 *
 * RETURNS: sum @a + @b
 */
int add(int a, int b)
{
	return a + b;
}
